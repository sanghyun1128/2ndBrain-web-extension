export const DELETE_MESSAGE_KO = "항목이 삭제되었습니다.";
export const DELETE_MESSAGE_EN = "has been deleted.";
